public class Events
{
    String Event;
    String Date;
    String Location;
    public Events(String eventName, String location, String date) {
        this.Event = eventName;
        this.Location = location;
        this.Date = date;
    }
};
