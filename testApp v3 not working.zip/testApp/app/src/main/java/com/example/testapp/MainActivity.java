package com.example.testapp;

import android.app.Dialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.TextView;
import android.database.Cursor;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Text;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

public class MainActivity extends AppCompatActivity
{

    public static final String DATABASE_NAME = "usersdb";

    SQLiteDatabase mDatabase;
    public ArrayList eventsList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatabase = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);


//        createEventsTable();

    }
    public void readEventOnClick(View view)
    {
        String [] text = readEvent();

        ((TextView) findViewById(R.id.textViewCard)).setText(text[0]);
    }
    public String[] readEvent()
    {
        mDatabase = openOrCreateDatabase("usersdb", MODE_PRIVATE, null);
        String selectQuery = "SELECT * FROM events";
        SQLiteDatabase db = mDatabase;
        Cursor cursor = db.rawQuery(selectQuery, null);
        String [] data = null;

        if(cursor.moveToFirst()){

            do{
                eventsList.add(new Events(cursor.getString(0), cursor.getString(1) ,cursor.getString(2)));

            }while(cursor.moveToNext());
        }
        cursor.close();
        return data;

    }

    public void createEventsTable(){
        mDatabase.execSQL(
                "CREATE TABLE IF NOT EXISTS events (\n" +
                        " eventName varchar(30) NOT NULL PRIMARY KEY, \n" +
                        " date datetime NOT NULL, \n" +
                        " location varchar(45) NOT NULL \n" + ")" +
                        ";"
        );
    }

}


    private static final String TAG = "MainActivity";

    private static final int ERROR_DIALOG_REQUEST = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(isServicesOK())
        {
            init();
        }
    }

    private void init()
    {
        Button btnMap = (Button) findViewById(R.id.btnMap);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MapActivity.class);
                startActivity(intent);
            }
        });
    }

    public boolean isServicesOK()
    {
        Log.d(TAG, "isServicesOK: checking google services version");
        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MainActivity.this);

        if (available == ConnectionResult.SUCCESS)
        //everything is fine and the user can make map requests
        {
            Log.d(TAG, "isServicesOK: Google Play Services is working");
            return true;
        }

        else if (GoogleApiAvailability.getInstance().isUserResolvableError(available))
        //an error occurred but we can resolve it
        {
            Log.d(TAG, "isServiceOK: an error occurred but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(MainActivity.this, available, ERROR_DIALOG_REQUEST);
            ((Dialog) dialog).show();
        }

        else
        {
            Toast.makeText(this, "You can't make map requests", Toast.LENGTH_SHORT).show();
        }

        return true;
    }
}

class Events
{
    String Event;
    String Date;
    String Location;
    public Events(String eventName, String location, String date) {
        this.Event = eventName;
        this.Location = location;
        this.Date = date;
    }
};
